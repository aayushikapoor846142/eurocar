<?php

use App\Helpers\CurrencyHelper;

if (!function_exists('currency')) {
    /**
     * Convert and format currency
     *
     * @param float $amount
     * @param string|null $currency
     * @return string
     */
    function currency($amount, $currency = null)
    {
        return CurrencyHelper::format($amount, $currency);
    }
}

if (!function_exists('convert_currency')) {
    /**
     * Convert currency amount
     *
     * @param float $amount
     * @param string|null $targetCurrency
     * @return float
     */
    function convert_currency($amount, $targetCurrency = null)
    {
        return CurrencyHelper::convert($amount, $targetCurrency);
    }
}

if (!function_exists('current_currency')) {
    /**
     * Get current currency
     *
     * @return string
     */
    function current_currency()
    {
        return CurrencyHelper::current();
    }
}

if (!function_exists('currency_symbol')) {
    /**
     * Get currency symbol
     *
     * @param string|null $currency
     * @return string
     */
    function currency_symbol($currency = null)
    {
        return CurrencyHelper::symbol($currency);
    }
}
