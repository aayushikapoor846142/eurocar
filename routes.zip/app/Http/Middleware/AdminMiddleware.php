<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
            //dd('AdminMiddleware is running');  // Check if this shows up

        if (!auth()->check() || !auth()->user()->is_admin) {
            return redirect('/')->with('error', 'Access denied.');
        }

        return $next($request);
    }
}
